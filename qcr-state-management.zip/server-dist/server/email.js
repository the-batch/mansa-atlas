import nodemailer from 'nodemailer';
export class EmailConfigurationError extends Error {
}
function createTransporter() {
    const host = process.env.SMTP_HOST?.trim();
    const from = process.env.SMTP_FROM?.trim();
    const portText = process.env.SMTP_PORT?.trim();
    const port = portText ? Number(portText) : 587;
    const username = process.env.SMTP_USER;
    const password = process.env.SMTP_PASS;
    if (!host || !from) {
        throw new EmailConfigurationError('Configuration requise : SMTP_HOST et SMTP_FROM.');
    }
    if (!Number.isInteger(port) || port < 1 || port > 65535) {
        throw new EmailConfigurationError('La variable SMTP_PORT doit être un port valide.');
    }
    if (Boolean(username) !== Boolean(password)) {
        throw new EmailConfigurationError('SMTP_USER et SMTP_PASS doivent être configurées ensemble.');
    }
    return nodemailer.createTransport({
        host,
        port,
        secure: process.env.SMTP_SECURE === 'true' || (process.env.SMTP_SECURE !== 'false' && port === 465),
        auth: username && password ? { user: username, pass: password } : undefined,
        connectionTimeout: 10_000,
        greetingTimeout: 10_000,
        socketTimeout: 20_000
    });
}
export async function sendReportEmail({ recipient, firstName, profileName, report }) {
    const transporter = createTransporter();
    await transporter.sendMail({
        from: process.env.SMTP_FROM,
        to: recipient,
        subject: 'Votre bilan patrimonial personnalisé - Mansa Capital',
        text: [
            `Bonjour ${firstName},`,
            '',
            'Vous trouverez en pièce jointe le bilan détaillé de votre diagnostic patrimonial.',
            `Votre profil est : ${profileName}.`,
            '',
            'Ce document est un support de réflexion et ne constitue pas un conseil financier, fiscal ou juridique.',
            '',
            'L’équipe Mansa Capital - L’Atlas'
        ].join('\n'),
        attachments: [{
                filename: 'bilan-patrimonial-mansa-capital.pdf',
                content: report,
                contentType: 'application/pdf'
            }]
    });
}
